package com.ibm.booking.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="bookings")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer bookingId;
	
	String fromDate;
	
	String tillDate;
	
	Boolean status;
	
	String bookingDate;
	
	@ManyToOne
	UserDetails userDetails;
	
	public Integer getBookingId() {
		return bookingId;
	}

	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getTillDate() {
		return tillDate;
	}

	public void setTillDate(String tillDate) {
		this.tillDate = tillDate;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	@OneToOne
	Car car;

	

	public Booking(String fromDate, String tillDate, Boolean status,Integer userId, Integer bookingId, Integer carId) {
		super();
		this.fromDate = fromDate;
		this.tillDate = tillDate;
		this.status = status;
		this.userDetails = new UserDetails(userId,"","","","","","");
		this.car = new Car(carId, "", "", "", null, null, "", "", "", true, null, "");
	}
	
	public Booking() {
		// TODO Auto-generated constructor stub
	}
	
	
}
