package com.ibm.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.booking.bean.Booking;
import com.ibm.booking.service.BookingService;

@RestController
public class BookingController {
	@Autowired
	BookingService service;
	
	@RequestMapping
	Iterable<Booking> getAllUsers(){
		return service.getAllBookings();
	}

}
