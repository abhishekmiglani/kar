package com.ibm.booking.repository;

import org.springframework.data.repository.CrudRepository;

import com.ibm.booking.bean.Booking;

public interface BookingRepository extends CrudRepository<Booking, Integer>{
		

}
