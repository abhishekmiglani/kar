package com.ibm.user.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.user.bean.UserDetails;
import com.ibm.user.service.UserDetailsService;

@RestController
@RequestMapping("")
public class UserDetailsController {
	
	@Autowired
	UserDetailsService service;
	
	@RequestMapping("/users")
	Iterable<UserDetails> getAllUsers(){
		return service.getAllUsers();
	}
	
	  @RequestMapping("/users/{id}") Optional<UserDetails>
	  getUserById(@PathVariable Integer id){ return service.getUserById(id); }
	 
	
//	@RequestMapping(method = RequestMethod.POST, value="/users")
//	boolean addUser(@RequestBody UserDetails user){
//		return service.addUser(user);
//	}
	
	@RequestMapping(method = RequestMethod.POST, value="/users/login")
	boolean userLogin(@RequestBody UserDetails user){
		return service.userLogin(user);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value="/users/{userId}")
	public void updateUserById(@RequestBody UserDetails user,@PathVariable Integer userId) {
		service.updateUser(user);
	}
	
	/*// no use of right now
	 * @RequestMapping(method = RequestMethod.PUT,value =
	 * "/users/{userId}/password-reset") public boolean matchPassword(@PathVariable
	 * Integer userId,@RequestBody String password,String newPassword) { return
	 * service.changePassword(userId, password, "kjh"); }
	 */
	
	
	
}
