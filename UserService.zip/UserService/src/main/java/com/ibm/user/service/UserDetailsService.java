package com.ibm.user.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.user.bean.UserDetails;
import com.ibm.user.repository.UserDetailsRepository;

@Service
public class UserDetailsService {

	@Autowired
	UserDetailsRepository repo;

	public Iterable<UserDetails> getAllUsers() {
		return repo.findAll();
	}

	public Optional<UserDetails> getUserById(Integer id){
		return repo.findById(id);
	}

	public boolean addUser(UserDetails user) {
		boolean isUserExist=repo.existsById(user.getUserId());
		if(isUserExist==false) {
		repo.save(user);
		}
		return !isUserExist;
		
		
	}

	public boolean userLogin(UserDetails user) {
		boolean isUserExists = false;
		Optional<UserDetails> log = repo.findByEmailAndPassword(user.getEmail(), user.getPassword());
		if (log.isPresent()) {
			isUserExists = true;
		}

		return isUserExists;
	}
	/*
	 * public boolean matchPassword(Integer userId, String password) {
	 * Optional<UserDetails> user = repo.findById(userId); if
	 * (password.equals(user.get().getPassword())) return true; return false;
	 * 
	 * } public boolean changePassword(Integer userId, String password, String
	 * newPassword) { if (matchPassword(userId, password)) { UserDetails user=
	 * repo.findById(userId).get(); user.setPassword(newPassword); repo.save(user);
	 * return true; } return false; }
	 */

	public void updateUser(UserDetails user) {
		repo.save(user);
	}
}
