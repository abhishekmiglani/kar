package com.ibm.wallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WalletMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WalletMsApplication.class, args);
	}

}
