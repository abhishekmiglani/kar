package com.ibm.wallet.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.wallet.bean.Wallet;
import com.ibm.wallet.bean.WalletTransaction;
import com.ibm.wallet.dao.WalletTransactionRepository;

@RestController
public class WalletTransactionController {
	@Autowired
	WalletTransactionRepository repo;
	
	@RequestMapping("/walletTransactions")
	Iterable<WalletTransaction> getWalletTransaction() {
		return repo.findAll();
	}
	
	@RequestMapping("/walletTransactions/{walletId}")
	List<WalletTransaction> getWalletTransactionByWalletId(@PathVariable Integer walletId) {
		return repo.findByWalletWalletId(walletId);
	}
	
	@RequestMapping(method = RequestMethod.POST, value ="/walletTransactions/{walletId}")
	public void addWalletTransaction(@RequestBody WalletTransaction walletTransaction,@PathVariable Integer walletId)
	{
		walletTransaction.setWallet(new Wallet(walletId,null,null));
		repo.save(walletTransaction);
	}
}
