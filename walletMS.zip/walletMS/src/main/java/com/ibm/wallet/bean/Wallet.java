package com.ibm.wallet.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Wallet {
	@Id
	Integer walletId;
	Integer userId;
	Double balance;
	
	public Wallet() {
		// TODO Auto-generated constructor stub
	}

	public Wallet(Integer walletId, Integer userId, Double balance) {
		super();
		this.walletId = walletId;
		this.userId = userId;
		this.balance = balance;
	}

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}
}
