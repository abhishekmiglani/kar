package com.ibm.wallet.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.ibm.wallet.bean.WalletTransaction;

public interface WalletTransactionRepository extends CrudRepository<WalletTransaction, Integer> {
	
	List<WalletTransaction> findByWalletWalletId(Integer walletId);
	
	
}
