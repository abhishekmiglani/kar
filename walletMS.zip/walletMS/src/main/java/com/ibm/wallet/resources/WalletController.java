package com.ibm.wallet.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.wallet.bean.Wallet;
import com.ibm.wallet.dao.WalletRepository;



@RestController
public class WalletController {
	@Autowired
	WalletRepository repo;
	
	@RequestMapping("/wallet/{userId}")
	Wallet getWalletByUserId(@PathVariable Integer userId) {

		return repo.findByUserId(userId);		
	}

}
